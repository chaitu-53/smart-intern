export const PORT = 5000;
export const mongoDBURL =
  "mongodb+srv://admin:jamankhanjk5@jamancluster.fmhh8m9.mongodb.net/";
